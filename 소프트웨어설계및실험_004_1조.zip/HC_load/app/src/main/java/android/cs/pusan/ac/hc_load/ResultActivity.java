package android.cs.pusan.ac.hc_load;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class ResultActivity extends AppCompatActivity {
    ImageView iv_image;
    Tmap tmapData;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        //TextView textView = (TextView)findViewById(R.id.parsetext);
        Intent intent = getIntent();
        String place = intent.getStringExtra("place");
        double lat = intent.getExtras().getDouble("lat");
        double lon = intent.getExtras().getDouble("lon");
       Task t = new Task(place);
        double x0 = lon;
        double y0 = lat;
        double x1 = Double.parseDouble(t.a.longitude);
        double y1 = Double.parseDouble(t.a.latitude);
        double x2 = Double.parseDouble(t.b.longitude);
        double y2 = Double.parseDouble(t.b.latitude);
        double x3 = Double.parseDouble(t.c.longitude);
        double y3 = Double.parseDouble(t.c.latitude);

        tmapData = new Tmap(x0, y0, x1, y1, x2, y2, x3, y3);
        iv_image = findViewById(R.id.iv_image);
        iv_image.setImageBitmap(tmapData.mapImage);

        TextView tv1 = (TextView)findViewById(R.id.tv1);
        tv1.setText("첫번째 장소는 "+t.a.storeName + "\n주소는 " + t.a.storeAddress + "입니다.\n" + "여기까지의 거리는 " + tmapData.distance1 +"m 이고 "+tmapData.time1 / 60+ "분 정도 걸립니다. \n");
        TextView tv2 = (TextView)findViewById(R.id.tv2);
        tv2.setText("두번째 장소는 "+t.b.storeName + "\n주소는 " + t.b.storeAddress + "입니다.\n"+ "여기까지의 거리는 " + tmapData.distance2 +"m 이고 "+tmapData.time2 / 60+ "분 정도 걸립니다. \n");
        TextView tv3 = (TextView)findViewById(R.id.tv3);
        tv3.setText("세번째 장소는 "+t.c.storeName + "\n주소는 " + t.c.storeAddress + "입니다.\n"+ "여기까지의 거리는 " + tmapData.distance3 +"m 이고 "+tmapData.time3 / 60+ "분 정도 걸립니다. \n");


    }
}