    package android.cs.pusan.ac.hc_load;

    import android.Manifest;
    import android.content.Intent;
    import android.content.pm.PackageManager;
    import android.os.Build;
    import android.os.Bundle;
    import android.view.View;
    import android.widget.Button;
    import android.widget.CheckBox;
    import android.widget.Toast;

    import androidx.annotation.RequiresApi;
    import androidx.appcompat.app.AppCompatActivity;

    public class permissionActivity extends AppCompatActivity {
        private CheckBox cbWIFI = findViewById(R.id.wifiCheck);
        private CheckBox cbGPS = findViewById(R.id.gpsCheck);
        private final int PERMISSIONS_ACCESS_FINE_LOCATION = 1000;
        private final int PERMISSIONS_ACCESS_COARSE_LOCATION = 1001;//권한 승인 코드

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_permission);

            Button okBtn = findViewById(R.id.okBtn);
            okBtn.setOnClickListener(new View.OnClickListener() {
                @RequiresApi(api = Build.VERSION_CODES.M)
                @Override
                public void onClick(View v) {
                    if (cbWIFI.isChecked() && cbGPS.isChecked()) {
                        startActivity(new Intent(getApplicationContext(), MainActivity.class));
                        // overridePendingTransition(R.anim.fade_in_activity, R.anim.fade_out_scale_in);
                        finish();
                    } else {
                        if (!cbWIFI.isChecked()) {
                            Toast.makeText(getApplicationContext(), "권한이 필요합니다.", Toast.LENGTH_LONG).show();
                            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, PERMISSIONS_ACCESS_COARSE_LOCATION);
                        }
                        if (!cbGPS.isChecked()) {
                            Toast.makeText(getApplicationContext(), "권한이 필요합니다.", Toast.LENGTH_LONG).show();
                            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, PERMISSIONS_ACCESS_FINE_LOCATION);
                        }
                    }
                }
            });

            Button cancelBtn = findViewById(R.id.cancelBtn);
            cancelBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    finish();
                }
            });
    /*
            cbGPS = findViewById(R.id.gpsCheck);
            cbWIFI = findViewById(R.id.wifiCheck);
    */
        }

        @RequiresApi(api = Build.VERSION_CODES.M)
        @Override
        protected void onResume() {
            cbWIFI.setChecked(checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED);
            cbGPS.setChecked(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED);

            if (cbWIFI.isChecked() && cbGPS.isChecked()) {
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
                // overridePendingTransition(R.anim.fade_in_activity, R.anim.fade_out_scale_in);
                finish();
            }
            super.onResume();
        }
    }